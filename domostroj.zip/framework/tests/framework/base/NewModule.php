<?php

class NewModule extends CModule {
}
